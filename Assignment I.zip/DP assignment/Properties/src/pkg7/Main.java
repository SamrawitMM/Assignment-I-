
package pkg7;

class Name {
    String firstName;
    String lastName;
    
    public void setFirstName(String firstName){
        this.firstName = firstName;
    }
    public String getFirstName(){
        return firstName;
    }
    public void setLastName(String lastName){
        this.lastName = lastName;
    }
    public String getLastName(){
        return lastName;
    }
}

public class Main {

    public static void main(String[] args) {
        Name name = new Name();
        name.setFirstName("samrawit");
        name.setLastName("mulugeta");
        System.out.println(name.getFirstName());
        System.out.println(name.getLastName());
    }
    
}
