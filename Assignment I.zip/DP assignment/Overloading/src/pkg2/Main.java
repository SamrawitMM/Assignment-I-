
package pkg2;

public class Main {
    
    // add method with two parameters
    public int add(int a, int b){
        return a + b;
    }
    
    // add method with three parameters
    public int add(int a, int b, int c){
        return a + b + c;
    }

    public static void main(String[] args) {
       Main add = new Main();
       System.out.println(add.add(1,2));
       System.out.println(add.add(1, 2, 3));
    }
    
}
