
package pkg1;

public class Main {

    // args array holds command line arguments
    // compiling using cmd, we can run the file
    // giving arguments the method returns the summation.
    
    public int add(String args[]){
        int a = Integer.parseInt(args[0]);
        int b = Integer.parseInt(args[1]);
        
        int result = a + b;
        return result;
    }
    public static void main(String args[]) {
        Main m = new Main();
        m.add(args);

    }
    
}
