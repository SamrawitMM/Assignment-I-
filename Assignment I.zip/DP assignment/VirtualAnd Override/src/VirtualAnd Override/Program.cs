﻿using System;


namespace VirtualAndOverride
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee emp = new Employee();
            Employee empManager = new Manager();
            Manager manager = new Manager();

             
            emp.Status();
            empManager.Status();
            manager.Status();
            manager.WorkPlace();


        }
    }

    class Employee
    {
        //virtual method - this method can be inherited
        public virtual void Status()
        {
            Console.WriteLine("Employee");
        }

    }

    class Manager : Employee
    {
        //override method 
        public override void Status()
        {
            Console.WriteLine("Manager");
        }

        public void WorkPlace()
        {
            Console.WriteLine("INSA");
        }
    }
}
