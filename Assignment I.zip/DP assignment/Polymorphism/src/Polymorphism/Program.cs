﻿using System;

    public class Employee
    {
    public string firstName = "first name";
    public string lastName = "last name";

    public virtual void PrintFullName()
    {
        Console.WriteLine(firstName + " " + lastName);
    }
        
   }

public class PermanentEmployee : Employee {
    public override void PrintFullName()
    {
        Console.WriteLine(firstName + " " + lastName + " : Temporary Employee");
    }

}

public class TemporaryEmployee : Employee
{
    public override void PrintFullName()
    {
        Console.WriteLine(firstName + " " + lastName + " : Permanent Employee");

    }
}
        public class Program {
    public static void Main() {
        Employee[] employees  = new Employee[3];
        employees[0] = new Employee();
        employees[1] = new TemporaryEmployee();
        employees[2] = new PermanentEmployee();

        foreach (Employee emp in employees) {
            emp.PrintFullName();
        }

        Console.ReadKey();
    }
}

