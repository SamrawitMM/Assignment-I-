﻿using System;

//Creating delegate
delegate int Calculator(int n, int m);

namespace Delegate
{
    public class Program
    {
        static int num;

        public static int AddNum(int p, int q) {
            num = p + q; 
            return num;
        }
        public static int MulNum(int p, int q) {
            num = p * q;
            return num;
        }

        public static int getNum() {
            return num;
        }
        static void Main(string[] args)
        {
            //Creating delegate instances
            Calculator nc1 = new Calculator(AddNum);
            Calculator nc2 = new Calculator(MulNum);

            //Calling the methods using the delegate objects
            nc1(25, 24);
            Console.WriteLine("Value of Num : {0}", getNum());
            nc2(5, 3);
            Console.WriteLine("Value of Num : {0}", getNum());
            Console.ReadKey();

        }
    }
}
