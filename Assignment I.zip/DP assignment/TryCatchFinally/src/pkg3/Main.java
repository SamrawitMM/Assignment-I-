
package pkg3;

public class Main {

    public static void main(String[] args) {
        try {
            int result = 156/0;
        }catch(ArithmeticException e){
            System.out.println(e);
        }finally {
            System.out.println("This message always displays");
    }
    }
    
}
